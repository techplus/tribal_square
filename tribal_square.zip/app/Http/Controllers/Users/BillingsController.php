<?php namespace App\Http\Controllers\Users;
use App\Http\Controllers\Controller;
use App\Repositories\PaypalRestInterface;
use App\Models\Payment;
use Auth;

class BillingsController extends Controller
{
	public function index(PaypalRestInterface $paypal)
	{
		$subscription = Payment::where('user_id',Auth::user()->id)->orderBy('updated_at','desc')->first();
		$this->data['transactions'] = $paypal->getTransactions($subscription->subscription_id);
		dd($this->data['transactions']);
	}
}