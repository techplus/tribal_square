<?php

return [
	'1' => 'First Year',
	'2' => 'Toodlers (1 to 3 years)',
	'3' => 'Preschooler (3 to 5 years)',
	'4' => 'Gradeschool (6 to 11 years)',
	'5' => 'Pre-teen/Teenagers (12 years and over)'
];