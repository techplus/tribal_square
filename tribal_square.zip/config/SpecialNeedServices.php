<?php

return [
	'1' => 'Administering Medication',
	'2' => 'Applied Behavior Analysis',
	'3' => 'Assistance With Transportation',
	'4' => 'Bathing',
	'5' => 'Positive Behavioral Support',
	'6' => 'Dressing Assistance',
	'7' => 'Feeding Assisatance',
	'8' => 'Grooming and Hygiene',
	'9' => 'Mobility Assistance',
	'10' => 'Special Meal Preparation (Foods to avoid, etc.)'
];