<?php


return [
	'Deal',
	'Classified'
];	