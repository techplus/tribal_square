<?php

return [
	'1' => 'Meal Preparation',
	'2' => 'Swimming Supervision',
	'3' => 'Crafts',
	'4' => 'Potty Training',
	'5' => 'Travel with Family',
	'6' => 'Willing to run errands as needed',
	'7' => 'Willing to drive childrens to events, school, appoinments, or carpooling',
	'8' => 'Laundry',
	'9' => 'Light Housekeeping'
];