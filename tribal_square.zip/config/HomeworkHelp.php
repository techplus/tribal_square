<?php

return [
	'1' => 'Finishing homework',
	'2' => 'Checking answers',
	'3' => 'Studying for a test',
	'4' => 'Proofreading',
	'5' => 'Pre-Algebra',
	'6' => 'Elementry Science',
	'7' => 'Science',
	'8' => 'English',
	'9' => 'Essay Writing',
	'10' => 'Social Studies'
];